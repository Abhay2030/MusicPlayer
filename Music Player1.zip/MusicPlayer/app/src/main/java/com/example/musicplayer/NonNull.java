package com.example.musicplayer;

public @interface NonNull {
}
