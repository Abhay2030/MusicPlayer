package com.example.musicplayer;

import android.Manifest;
import android.content.pm.PackageManager;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.io.IOException;

class MainActivity extends AppCompatActivity {

    private static final int REQUEST_PERMISSION = 100;
    private MediaPlayer mediaPlayer;
    private TextView statusTextView;
    private SeekBar volumeSeekBar;
    private SeekBar progressSeekBar;
    private SeekBar equalizerBand1;
    private SeekBar equalizerBand2;
    private SeekBar equalizerBand3;
    private SeekBar equalizerBand4;
    private SeekBar equalizerBand5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQUEST_PERMISSION);
        }

        statusTextView = findViewById(R.id.status);
        volumeSeekBar = findViewById(R.id.seekVol);
        progressSeekBar = findViewById(R.id.seekBar);
        equalizerBand1 = findViewById(R.id.equalizerBand1);
        equalizerBand2 = findViewById(R.id.equalizerBand2);
        equalizerBand3 = findViewById(R.id.equalizerBand3);
        equalizerBand4 = findViewById(R.id.equalizerBand4);
        equalizerBand5 = findViewById(R.id.equalizerBand5);

        setupMediaPlayer();
        setupVolumeControl();
        setupProgressControl();
        setupEqualizerControls();
    }

    private void setupMediaPlayer() {
        String filePath = Environment.getExternalStorageDirectory().getPath() + "/Music/sample_music.mp3";
        mediaPlayer = new MediaPlayer();
        try {
            mediaPlayer.setDataSource(filePath);
            mediaPlayer.prepare();
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Error loading audio file", Toast.LENGTH_SHORT).show();
        }
    }

    public void play(View view) {
        if (mediaPlayer != null && !mediaPlayer.isPlaying()) {
            mediaPlayer.start();
            statusTextView.setText("Playing");
        }
    }

    public void pause(View view) {
        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            mediaPlayer.pause();
            statusTextView.setText("Paused");
        }
    }

    public void stop(View view) {
        if (mediaPlayer != null) {
            mediaPlayer.stop();
            mediaPlayer.reset();
            setupMediaPlayer(); // Reset the MediaPlayer with the audio source
            statusTextView.setText("Stopped");
            progressSeekBar.setProgress(0);
        }
    }

    public void previous(View view) {
        // Add your logic for playing the previous track
        statusTextView.setText("Previous Track");
    }

    public void next(View view) {
        // Add your logic for playing the next track
        statusTextView.setText("Next Track");
    }

    public void volumeUp(View view) {
        int currentVolume = volumeSeekBar.getProgress();
        if (currentVolume < volumeSeekBar.getMax()) {
            volumeSeekBar.setProgress(currentVolume + 1);
            mediaPlayer.setVolume(volumeSeekBar.getProgress() / 100f, volumeSeekBar.getProgress() / 100f);
        }
    }

    public void volumeDown(View view) {
        int currentVolume = volumeSeekBar.getProgress();
        if (currentVolume > 0) {
            volumeSeekBar.setProgress(currentVolume - 1);
            mediaPlayer.setVolume(volumeSeekBar.getProgress() / 100f, volumeSeekBar.getProgress() / 100f);
        }
    }

    private void setupVolumeControl() {
        volumeSeekBar.setMax(100);
        volumeSeekBar.setProgress(50);
        volumeSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                mediaPlayer.setVolume(progress / 100f, progress / 100f);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });
    }

    private void setupProgressControl() {
        progressSeekBar.setMax(mediaPlayer.getDuration());
        progressSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    mediaPlayer.seekTo(progress);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });
    }

    private void setupEqualizerControls() {
        // Implement your equalizer setup logic here
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mediaPlayer != null) {
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }
}
