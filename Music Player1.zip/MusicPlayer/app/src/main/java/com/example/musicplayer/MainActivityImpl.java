package com.example.musicplayer;

public class MainActivityImpl extends MainActivity {
}
